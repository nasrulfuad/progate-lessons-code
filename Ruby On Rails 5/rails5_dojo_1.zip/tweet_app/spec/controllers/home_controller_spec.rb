require 'rails_helper'

RSpec.describe HomeController, type: :controller do

end
