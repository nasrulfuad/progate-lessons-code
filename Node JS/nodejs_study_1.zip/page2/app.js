// Paste the code to use express
const express = require('express');
const app = express();