-- get the "name" and "price" columns from the "purchases" table
select name, price from purchases;