-- get all columns from the "purchases" table
select * from purchases;