-- get the "price" column from the "purchases" table
select price from purchases;

