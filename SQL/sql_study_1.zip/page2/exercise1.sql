-- get the "name" column from the "purchases" table
select name from purchases;