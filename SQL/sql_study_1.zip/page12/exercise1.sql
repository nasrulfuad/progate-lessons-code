-- after "FROM purchases" add code to put rows in descending order by the "price" column

SELECT *
FROM purchases
ORDER BY price DESC;