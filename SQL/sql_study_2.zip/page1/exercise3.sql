-- get rows from the name column with duplicates excluded

SELECT DISTINCT(name)
FROM purchases;