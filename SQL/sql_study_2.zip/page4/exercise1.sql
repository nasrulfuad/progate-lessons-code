-- get the average of the values in the price column

SELECT avg(price)
FROM purchases;