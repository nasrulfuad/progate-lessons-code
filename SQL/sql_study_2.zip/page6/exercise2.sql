-- get the lowest value in the price column 

SELECT min(price)
FROM purchases;