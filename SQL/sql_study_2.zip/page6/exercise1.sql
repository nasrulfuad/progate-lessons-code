-- get the highest price of all the values in the price column

SELECT max(price)
FROM purchases;