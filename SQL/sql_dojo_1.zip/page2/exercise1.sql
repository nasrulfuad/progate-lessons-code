-- get the average age of all users
select avg(age) from users