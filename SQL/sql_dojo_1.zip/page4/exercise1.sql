-- get the names, prices and profit values for all products
select name, price , (price - cost) from items;