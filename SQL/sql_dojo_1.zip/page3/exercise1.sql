-- get the names of every product without including duplicates
select  DISTINCT(name) from items;