-- get the name and price of every product in descending order by price
select name, price from items order by price desc;