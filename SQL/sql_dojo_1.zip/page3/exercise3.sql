-- get all rows that contain the string "shirt"
select * from items where name like "%shirt%"