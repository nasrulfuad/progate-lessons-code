CREATE TABLE IF NOT EXISTS "students" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar, "course" varchar);
INSERT INTO students VALUES(1,'Kevin','HTML');
INSERT INTO students VALUES(2,'Emma','SQL');
INSERT INTO students VALUES(3,'Chris','HTML');
INSERT INTO students VALUES(4,'Kate','Java');
INSERT INTO students VALUES(5,'Tom','SQL');
INSERT INTO students VALUES(6,'jaden','HTML');
INSERT INTO students VALUES(7,'Emily','PHP');
INSERT INTO students VALUES(8,'Julia','SQL');
