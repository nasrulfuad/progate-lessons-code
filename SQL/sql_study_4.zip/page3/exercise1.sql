-- delete the record with the id of 7 within the students table
delete from students where id = 7;
-- do not delete the following query
SELECT * FROM students;
