SELECT goals
FROM players where name = 'Will';