-- Use AS to name the column "total team score"
SELECT sum(goals) as 'total team score'
FROM players;