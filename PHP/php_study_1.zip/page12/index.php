<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    // Write the for loop below
    for($i = 51; $i <= 100; $i++){
      echo "$i <br>";
    }
    
  ?>

</body>
</html>