<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <!-- Output 5 + 7 below -->
  <?php
    echo 5 + 7;
  ?>

  <br>

  <!-- Output '5 + 7' below -->
  <?php
    echo '5 + 7';
  ?>

</body>
</html>