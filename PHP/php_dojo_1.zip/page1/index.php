<?php
  echo 'Hello, PHP';
  echo '<br>';
  echo '10 + 7';
?>