<?php
// Define the Menu class
class Menu
{
  
}

// Assign a new instance of the Menu class to the $curry variable
$curry = new Menu();

// Assign a new instance of the Menu class to the $pasta variable
$pasta = new Menu();

?>