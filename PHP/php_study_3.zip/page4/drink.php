<?php 
// Import the menu.php file
require_once 'menu.php';

// Create a Drink class that inherits from the Menu class
class Drink extends Menu {
  
}

?>