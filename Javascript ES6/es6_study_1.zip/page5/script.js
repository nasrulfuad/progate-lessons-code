// Output the combination of "Master " and "White"
console.log('Master'+ 'White');

// Output the combination of "20" and "15" (as a single string)

console.log('20'+'15');