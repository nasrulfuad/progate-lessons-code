const rank = 2;

switch (rank) {
  case 1:
    console.log("You won a gold medal!");
    break;

  // Add a case for when rank is 2
  case 2:
    console.log('You won a silver medal!');
  break;
  // Add a case for when rank is 3
  case 3:
  console.log('You won a bronze medal!');
  break;
}
