const level = 12;

// Add an if statement with the condition: level > 10
if(level > 10) {
  console.log('Your level is higher than 10');
}
