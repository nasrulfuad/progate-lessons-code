let name = "Ken the Ninja";
console.log(name);

// Update the name variable with the value "Birdie"
name = 'Birdie';

// Output the value of the name variable

console.log(name);