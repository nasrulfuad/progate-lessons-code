// Assign a function to the hello constant
const hello = function() {
  console.log('Hello');
  console.log('I am ____');
}




// Call the function assigned to the hello constant

hello();