// Add the parameters number1 and number2 to the function 
const add = (number1, number2) => {
  // Print the sum of number1 and number2
  console.log(number1+number2);
  
};

// Call the function with 5 and 7 as arguments

add(5,7);