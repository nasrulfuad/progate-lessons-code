// Remove the code below


// Remove the code above

// Import the constant dog
import dog from './dogData';

dog.info();