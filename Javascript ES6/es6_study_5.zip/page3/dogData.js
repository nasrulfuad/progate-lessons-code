import Dog from "./dog";

// Make the dog constant accessible in this file
const dog = new Dog("Leo", 4, "Chihuahua");

// Export the constant dog
export default dog;
