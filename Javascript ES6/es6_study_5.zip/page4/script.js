// Rewrite the below and import the constants dog1 and dog2
import {dog1, dog2} from "./dogData";

// Copy from the instructions and rewrite it so that the constants dog1 and dog2 are printed
console.log("---------");
dog1.info();
console.log("---------");
dog2.info();