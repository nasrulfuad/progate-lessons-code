import Dog from "./dog";

// Note the 2 constants dog1 and dog2 below
const dog1 = new Dog("Leo", 4, "Chihuahua");
const dog2 = new Dog("Ben", 2, "Poodle");

// Rewrite the below and export the constants dog1 and dog2
export {dog1, dog2};
