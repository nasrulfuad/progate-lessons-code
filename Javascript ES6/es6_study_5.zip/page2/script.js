// Import the Dog class
import Dog from './dog';

const dog = new Dog("Leo", 4, "Chihuahua");
dog.info();
