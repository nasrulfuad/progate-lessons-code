const characters = [
  {name: "Ken the Ninja", age: 14},
  {name: "Master White", age: 1000}
];

// Print the 1st element of the characters array
console.log(characters[0]);

// Print value of the name property of the character array's 2nd element
console.log(characters[1].name);
