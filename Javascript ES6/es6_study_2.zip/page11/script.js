const character = {name: "Ken the Ninja", age: 14};

// Print the value of the character's name property
console.log(character.name);

// Change the value of the character's age to 20 
character.age = 20;

// Print the character constant in the console
console.log(character);
