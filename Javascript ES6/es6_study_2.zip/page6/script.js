const animals = ["dog", "cat", "sheep"];

// Print the first element of the array
console.log(animals[0]);

// Print the 3rd element in the array
console.log(animals[2]);
