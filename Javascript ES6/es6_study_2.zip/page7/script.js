const animals = ["dog", "cat", "sheep"];

// Change the 3rd element of the animals array to "rabbit"
animals[2] = 'rabbit';

// Print the 3rd element of the animals array in the console
console.log(animals[2]);
