class Animal {
  // Add a constructor
  constructor() {
   console.log('Created a new instance');
  }
}

const animal = new Animal();
