from food import Food
from drink import Drink

food1 = Food('Sandwich', 5)
food1.calorie_count = 330

# Call the info method from food1 and output the return value
print(food1.info())
