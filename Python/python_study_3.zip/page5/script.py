# Add a default value for name
def print_hand(hand, name = "Guest"):
    print(name + ' picked: ' + hand)

# Add an argument to print_hand
print_hand("Rock")