x = 10

# Create a while loop that repeats while x is greater than 0
while x > 0:
    # Print the x variable 
    print(x)
    # Subtract 1 from the x variable
    x -= 1