# Assign a dictionary to the fruits variable
fruits = {"apple": "manzana", "orange": "naranja"}

# Print the value with the key 'orange'
print(fruits["orange"])

# By using the fruits dictionary, print 'apple is ___ in Spanish'

print("apple is "+ str(fruits["apple"]) +" in Spanish")