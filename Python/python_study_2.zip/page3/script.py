fruits = ['apple', 'banana', 'orange']

# Add 'grape' to 'fruits'
fruits.append("grape")

# Print 'fruits'
print(fruits)

# Update the element at index 0
fruits[0] = "cherry"

# Print the element at index 0
print(fruits[0])

