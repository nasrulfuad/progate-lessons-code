fruits = {'apple': 1, 'banana': 2, 'orange': 4}

# Update the value with the key 'banana' to 3
fruits["banana"] = 3

# Add an element to fruits with the key 'grape' and the value 5
fruits["grape"] = 5

# Print fruits

print(fruits)