fruits = {'apple': 'manzana', 'orange': 'naranja', 'grape': 'uva'}

# With a for loop, print '___ is ___ in Spanish'
for key in fruits:
    print( str(key) + "is "+ str(fruits[key]) +" in Spanish")