# Print 'Hello World'
print("Hello World")