money = 20
print(money)

# Add 50 to the money variable
money += 50

# Print the value of the money variable
print(money)