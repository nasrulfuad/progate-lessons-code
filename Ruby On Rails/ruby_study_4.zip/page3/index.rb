class Menu
  # Add instance variables name and price
  attr_accessor :name
  attr_accessor :price
end
