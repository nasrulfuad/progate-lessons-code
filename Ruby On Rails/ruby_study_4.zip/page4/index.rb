class Menu
  attr_accessor :name
  attr_accessor :price
end

# Create an instance of Menu, then assign it into the menu1 variable
menu1 = Menu.new