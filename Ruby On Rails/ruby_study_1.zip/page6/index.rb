# Assign the string "Ken the Ninja" to the name variable
name = 'Ken the Ninja'

# Print the name variable

puts name