score = 80

# Print the result of 「score > 80」
puts score > 80

# Print the result of 「score <= 80」
puts score <= 80

# if the score is less than or equal to 80, print "You can do better!"
if score <= 80
  puts "You can do better!"
end