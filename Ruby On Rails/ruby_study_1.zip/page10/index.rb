length = 9
width = 8
puts width
puts length * width

puts "----"
# Update the width variable by adding 5 to it
width += 5

puts width
puts length * width
