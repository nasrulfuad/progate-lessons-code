# Print 「Hello Ruby」
puts 'Hello Ruby'

# Make the following line a comment
# puts "Hello Progate"
