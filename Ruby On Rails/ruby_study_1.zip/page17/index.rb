score = 96

# if the score ranges from 95 to 99 (inclusive), print "Good job! Almost perfect."
if score >= 95 && score <= 99
  puts "Good job! Almost perfect."
end