score = 92

# if the score is greater than 80, print "Great job!"
if score > 80
  puts "Great job!"
end