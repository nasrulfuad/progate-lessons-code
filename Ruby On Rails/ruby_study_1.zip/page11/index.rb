length = 9
width = 8
area = length * width

# Print "The area is ___" using the area variable
puts "The area is #{area}"
