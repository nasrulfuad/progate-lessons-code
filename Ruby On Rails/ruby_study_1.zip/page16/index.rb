score = 73

# Add an elsif statement to print "Not bad!" when the score is greater than 60
if score > 80
  puts "Great job!"
elsif score > 60
  puts "Not bad!"
else
  puts "You can do better!"
end

    