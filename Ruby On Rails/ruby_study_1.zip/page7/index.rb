text = "Let's learn programming"

# Concatenate the text variable and the string, then print the result
puts text + " using Progate"

length = 8
width = 9

# Print the result of length * width
puts length * width
