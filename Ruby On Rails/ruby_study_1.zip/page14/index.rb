score = 100

# if the score is 100, print "Great job!"
if score == 100
  puts "Great job!"
end

# if the score is not 100, print "You can do better!"
if score != 100
  puts "You can do better!"
end