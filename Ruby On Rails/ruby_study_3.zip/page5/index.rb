def print_info(item)
  puts "Welcome to Ninja Electronics!"
  puts "#{item}s are on sale today!"
end

print_info("Headphone")

# Remove the following code
