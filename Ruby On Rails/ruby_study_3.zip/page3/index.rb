def introduce(name)
  puts "Hello"
  puts "My name is #{name}"
end

# Call the introduce method with your own name
introduce("Koko")
