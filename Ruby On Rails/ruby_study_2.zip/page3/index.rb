languages = ["Japanese", "English", "Spanish"]

# Get each element of languages using the each method, and print "I can speak ___"
languages.each do |language|
  puts "I can speak #{language}"
end
