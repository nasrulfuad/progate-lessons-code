exam = {subject: "Math", score: 80}

# Print the value with the key :grade
puts exam[:grade]

# Print nil
puts nil