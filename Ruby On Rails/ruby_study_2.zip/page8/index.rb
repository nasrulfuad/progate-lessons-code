# Use the shorthand syntax for keys with symbols
exam = {subject: "Math", score: 80}

puts exam[:subject]
