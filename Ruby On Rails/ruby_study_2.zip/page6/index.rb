exam = {"subject" => "Math", "score" => 80}

# Print the value with the key "subject"
puts exam["subject"]

# Update the value with the key "subject" to "Science"
exam["subject"] = "Science"

# Print the value with the key "subject" again
puts exam["subject"]

# Add an element with the key "grade" and the value "B"
exam["grade"] = "B"

# Print the value with the key "grade"
puts exam["grade"]
