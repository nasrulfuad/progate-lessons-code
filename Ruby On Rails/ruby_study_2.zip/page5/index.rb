# Assign a hash into the exam variable
exam = {"subject" => "Math", "score" => 80}

# Print the exam variable

puts exam