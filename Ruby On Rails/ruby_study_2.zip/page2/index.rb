languages = ["Japanese", "English", "Spanish"]

# Print the element at index 1
puts languages[1]

# Combine the string and the element at index 0, and print the result
puts "I can speak #{languages[0]}"