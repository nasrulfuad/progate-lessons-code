languages = ["Japanese", "English", "Spanish"]
border = "---------------------"

languages.each do |language|
  # Print the border variable
  puts border
  puts "I can speak #{language}"
end

# Remove the following code

