# Rewrite the keys with symbols
exam = {:subject => "Math", :score => 80}

# Print the value with the key :score
puts exam[:score]
