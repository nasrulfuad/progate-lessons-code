# Import the Date class using require
require 'date'

# Create an instance of Date, then assign it to the birthday variable
birthday = Date.new(2020, 9, 10)

# Print the birthday variable
puts birthday

# Call birthday's sunday? method, then print the return value
puts birthday.sunday?