require "./menu"

class Drink < Menu
  # Add the volume instance variable
  attr_accessor:volume
end
