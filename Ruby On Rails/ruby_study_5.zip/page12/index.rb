require "date"

# Assign the return value of Date.today to the today variable
today = Date.today

# Print the today variable
puts today

# Call today's sunday? method, then print the return value
puts today.sunday?