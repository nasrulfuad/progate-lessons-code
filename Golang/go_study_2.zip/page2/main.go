package main

// Import the fmt package
import "fmt"

func main() {
    // Using the fmt package, change the output message to: Hello, world
    fmt.Println("Hello, world")
}
