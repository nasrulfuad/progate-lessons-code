package main

func main() {
    // Print the number 7
    println(7)
    
    // Print the sum of 9 and 3
    println(9 + 3)
    
    // Print "9 + 3" as a string
    println("9 + 3")
    
}
