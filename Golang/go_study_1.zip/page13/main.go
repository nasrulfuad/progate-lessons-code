package main

func main() {
    x := 7 * 10
    y := 5 * 6
    
    // Make an if statement for when the value of x is equal to 70
    if x == 70 {
        println("x is equal to 70")
    }
    
    
    
    // Make an if statement for when the value of y is not equal to 40
    if y != 40 {
        println("y is not equal to 40")
    }
    
}
