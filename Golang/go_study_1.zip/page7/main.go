package main

func main() {
    // Define the message variable and assign it the string "Hello, world"
    var message string = "Hello, world"
    
    // Print the value of the message variable
    println(message)
    
}
