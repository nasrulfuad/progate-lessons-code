package main

func main() {
    // Using shorthand, define and assign the value "Hello, world" to the message variable 
    message := "Hello, world"
    
    // Using shorthand, define and assign the value 100 to the number variable 
    number := 100
    
    // Print the values of both the number and message variables
    println(message, number)
    
}
