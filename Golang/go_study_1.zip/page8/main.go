package main

func main() {
    var message string = "Hello, world"

    // Change the value of the message variable to the string value "Hello, Go"
    message = "Hello, Go"
	
	println(message)
}
