import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        {/* Use the <h1> tag to display "Hello World" */}
        <h1>Hello World</h1>
        
        {/* Use the <p> tag to display "Let's study React together!" */}
        <p>Let's study React together!</p>
        
      </div>
    );
  }
}

export default App;
