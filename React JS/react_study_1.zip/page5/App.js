// Import React
import React from 'react';

// Define the App class
class App extends React.Component {
  render() {
    return (
      <h1>Hello React</h1>
    );
  }
};

// Export the App class
export default App;