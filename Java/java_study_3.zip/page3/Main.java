class Main {
  public static void main(String[] args) {
    // Pass the argument "Kate Jones"
    printData("Kate Jones");
    
    // Pass the argument "John Christopher Smith"
    printData("John Christopher Smith");
    
  }

  // Edit the method to accept an argument
  public static void printData(String name) {
    // Output "My name is ____."
    System.out.println("My name is " + name + ".");
    
  }
}
