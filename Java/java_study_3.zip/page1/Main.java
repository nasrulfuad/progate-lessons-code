class Main {
  public static void main(String[] args) {
    hello();
  }
  
  public static void hello() {
    // Replace "Hello World" with "Hello Java"
    System.out.println("Hello Java");
  }
}
