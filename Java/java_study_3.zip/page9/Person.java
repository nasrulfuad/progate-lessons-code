class Person {
  public static void hello() {
    // Replace "Hello World" with "Hello Java"
    System.out.println("Hello Java");
  }
}
