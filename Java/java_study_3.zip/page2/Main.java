class Main {
  public static void main(String[] args) {
    // Call the printData method
    printData();
    
  }
  
  // Define the printData method
  public static void printData() {
    System.out.println("My name is Kate Jones.");
  }
  
}
