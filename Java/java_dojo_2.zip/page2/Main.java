class Main {
  public static void main(String[] args) {
    Bicycle bicycle = new Bicycle();
    bicycle.setName("Bianchi");
    System.out.println("【Bicycle Info】");
    System.out.println("Name: " + bicycle.getName());
  }
}