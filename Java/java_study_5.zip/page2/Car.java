// Inherit the Vehicle class
class Car extends Vehicle
{

}