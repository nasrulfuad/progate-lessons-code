// Inherit the Vehicle class
class Bicycle extends Vehicle
{
  
}