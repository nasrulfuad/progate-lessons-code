class Car extends Vehicle
{
  
}