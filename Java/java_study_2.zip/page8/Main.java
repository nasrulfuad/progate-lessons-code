class Main {
  public static void main(String[] args) {
    int number = 10;
    
    // Create a while loop that repeats while number is greater than 0
    while(number > 0) {
      System.out.println(number);
      number--;
    }
    
  }
}