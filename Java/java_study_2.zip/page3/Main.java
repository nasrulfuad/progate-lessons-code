class Main {
  public static void main(String[] args) {
    // Use && or || to print true
    System.out.println(true || false);
    
    // Use && or || to print false
    System.out.println(false && true);
    
    // Print the result of 8 < 5 AND 3 >= 2
    System.out.println(8 < 5 && 3 >= 2);
    
    // Print the result of 8 < 5 OR 3 >= 2
    System.out.println(8 < 5 || 3 >= 2);
    
    // Print the result of NOT 8 < 5
    System.out.println(!(8 < 5));
    
  }
}