class Main {
  public static void main(String[] args) {
    // Assign a list of languages to the languages variable
    String[] languages = {"Ruby", "PHP", "Python"};
    
    // Print the element at index 1
    System.out.println(languages[1]);
    
    // Update the element at index 1 with "Java"
    languages[1] = "Java";
    
    // Print the element at index 1
    System.out.println(languages[1]);
    
  }
}