class Main {
  public static void main(String[] args) {
    // Declare the number variable of type int
    int number;
    
    // Assign 3 to the number variable
    number = 3;
    
    // Print the number variable
    System.out.println(number);
    
    // Declare the name variable of type String
    String name;
    
    // Assign "Bob" to the name variable
    name = "Bob";
    
    // Print the name variable
    System.out.println(name);
    
    
  }
}
