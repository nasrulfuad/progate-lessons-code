class Main {
  public static void main(String[] args) {
    int number = 11;
    String text = "Ruby";
    System.out.println(number);
    System.out.println(text);
    
    // Update the number variable with 9
    number = 9;
    
    // Print the number variable
    System.out.println(number);
    
    // Update the text variable with "Java"
    text = "Java";
    
    // Print the text variable
    System.out.println(text);
    
  }
}
