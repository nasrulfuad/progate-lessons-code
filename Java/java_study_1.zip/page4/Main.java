class Main {
  public static void main(String[] args) {
    // Print the result of 12 divided by 3
    System.out.println(12 / 3);
    
    // Print the result of 3 times 
    System.out.println(3 * 6);
    
    // Print the remainder of 8 divided by 3
    System.out.println(8 % 3);
    
  }
}
