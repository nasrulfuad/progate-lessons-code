class Main {
  public static void main(String[] args) {
    int number = 8;
    
    // Update the number variable by multiplying 7 to it
    number *= 7;
    
    // Print the number variable
    System.out.println(number);
    
    // Update the number variable by adding 1 to it
    number += 1;
    
    // Print the number variable
    System.out.println(number);
    
  }
}
