class Main {
  public static void main(String[] args) {
    int month = 12;
    int date = 31;
    
    // Concatenate the variables with "/" to print "12/31"
    System.out.println(month + "/" + date);
    
    // Print the result of 7 / 2
    System.out.println(7 / 2);
    
    // Print the result of 7.0 / 2.0
    System.out.println(7.0 / 2.0);
    
    // Print the result of 7 / 2.0
    System.out.println(7 / 2.0);
    
  }
}
