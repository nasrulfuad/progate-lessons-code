class Main {
  public static void main(String[] args) {
    // Declare the number1 variable of type double, and assign 8.5 to it
    double number1 = 8.5;
    
    // Declare the number2 variable of type double, and assign 3.4 to it
    double number2 = 3.4;
    
    // Print the result of number1 + number2
    System.out.println(number1 + number2);
    
    // Print the result of number1 - number2
    System.out.println(number1 - number2);
    
  }
}
