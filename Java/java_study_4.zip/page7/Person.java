class Person {
  public String name;

  // Define the constructor for the Person class
  Person() {
    System.out.println("Created an instance of the Person class.");
  }

  public void hello() {
    System.out.println("Hello, my name is " + this.name + ".");
  }
}
