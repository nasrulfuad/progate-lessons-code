class Person {
  public void hello() {
    // Rewrite the print statement to output "Hello"
    System.out.println("Hello");
  }
}
