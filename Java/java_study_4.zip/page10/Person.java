class Person {
  // Declare the instance fields
  public String firstName;
  public String lastName;
  public int age;
  public double height;
  public double weight;
  // Define the constructor to set the instance fields
  
  Person(String firstName, String lastName, int age, double height, double weight) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.height = height;
    this.weight = weight;
  }
  
}
