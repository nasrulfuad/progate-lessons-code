class Main {
  public static void main(String[] args) {
    // Create a new Person instance with "Kate Jones" as an argument
    Person person1 = new Person("Kate Jones");
    person1.hello();

    // Create a new Person instance with "John Christopher Smith" as an argument
    Person person2 = new Person("John Christopher Smith");
    person2.hello();
  }
}
