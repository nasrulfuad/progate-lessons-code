// Define the Person class
class Person {
  
}