class Main {
  public static void main(String[] args) {
    // Assign a new instance of the Person class to the person1 variable
    Person person1 = new Person();
    
    // Assign a new instance of the Person class to the person2 variable
    Person person2 = new Person();
    
  }
}
