$(function() {
  // Assign the text of the #title element to the title variable
  var title = $('#title').text();
  
  // Use the text method to replace the text of the #title-text element
  $('#title-text').text(title);
  
});