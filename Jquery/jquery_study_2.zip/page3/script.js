$(function() {
  $('#login-show').click(function() {
    $('#login-modal').fadeIn();
  });
  
  // Add the click() method for 
  $('.signup-show').click(function() {
      $('#signup-modal').fadeIn();
  });

});
