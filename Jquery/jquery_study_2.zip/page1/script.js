// Add the method for the document ready event
$(function(){

});