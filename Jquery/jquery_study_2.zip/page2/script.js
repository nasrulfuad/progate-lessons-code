$(function() {
  // Add a click() method for #login-show
  $('#login-show').click(function() {
    $('#login-modal').fadeIn();
  });
  
});