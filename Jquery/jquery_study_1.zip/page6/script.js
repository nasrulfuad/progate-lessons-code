$(function(){
  // Add a click() method for #hide-text
  $('#hide-text').click(function() {
    $('#text').slideUp();
  });
  
});