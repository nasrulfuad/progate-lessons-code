$(function() {
  // Use the fadeOut() method to hide <img> elements
  $('img').fadeOut();
  
  // Use the slideUp() method to hide <p> elements
  $('p').slideUp();
  
});